import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { TabComponent } from './tab/tab.component';
import { SlideComponent } from './slide/slide.component';

import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { SliderService } from './slider.service';
import { TabService } from './tab.service';

@NgModule({
  declarations: [
    AppComponent,
    TabComponent,
    SlideComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    HttpModule
  ],
  providers: [SliderService, TabService],
  bootstrap: [AppComponent]
})
export class AppModule { }
