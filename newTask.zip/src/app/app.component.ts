import { Component } from '@angular/core';
import { TabComponent } from './tab/tab.component';
import { SlideComponent } from './slide/slide.component';
import { SliderService } from './slider.service';
import { TabService } from './tab.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'newTask';
}
