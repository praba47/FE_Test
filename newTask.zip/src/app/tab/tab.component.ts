import { Component, OnInit } from '@angular/core';
import { TabService } from '../tab.service';

@Component({
  selector: 'app-tab',
  templateUrl: './tab.component.html',
  styleUrls: ['./tab.component.css']
})
export class TabComponent implements OnInit {
  viewMode = 'tab1';

  tabArr = [];
  errorMsg: string;

  constructor(private _tabService: TabService) { }


  ngOnInit() {

    this._tabService.getTabEvents().subscribe(
      data => { 
        //console.log(data);
         this.tabArr = data;
         console.log(this.tabArr);        
        } 
    );

  }

}
