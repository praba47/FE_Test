import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map'

@Injectable({
  providedIn: 'root'
})
export class TabService {

  constructor (private http: HttpClient) {}

  getJsonUrl = "../assets/getTabData.json";

  getTabEvents(): Observable<any> {
    let tabData : any;
    tabData = this.http.get(this.getJsonUrl, {responseType: 'json'});                    
    return tabData;
  }
}
