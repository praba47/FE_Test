import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map'

@Injectable({
  providedIn: 'root'
})
export class SliderService {

  constructor (private http: HttpClient) {}

  getJsonUrl = "../assets/getSliderData.json";

  getEvents(): Observable<any> {
    let datas : any;
    datas = this.http.get(this.getJsonUrl, {responseType: 'json'});                    
    return datas;
  }

}
